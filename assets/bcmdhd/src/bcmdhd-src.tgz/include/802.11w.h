/*
 * Fundamental types and constants relating to 802.11w -
 * "Protected Management Frames"
 *
 * Copyright (C) 2022, Broadcom.
 *
 *      Unless you and Broadcom execute a separate written software license
 * agreement governing use of this software, this software is licensed to you
 * under the terms of the GNU General Public License version 2 (the "GPL"),
 * available at http://www.broadcom.com/licenses/GPLv2.php, with the
 * following added to such license:
 *
 *      As a special exception, the copyright holders of this software give you
 * permission to link this software with independent modules, and to copy and
 * distribute the resulting executable under terms of your choice, provided that
 * you also meet, for each linked independent module, the terms and conditions of
 * the license of that module.  An independent module is a module which is not
 * derived from this software.  The special exception does not apply to any
 * modifications of the software.
 *
 *
 * <<Broadcom-WL-IPTag/Dual:>>
 */

#ifndef _802_11w_h_
#define _802_11w_h_

#ifndef _TYPEDEFS_H_
#include <typedefs.h>
#endif

/* This marks the start of a packed structure section. */
#include <packed_section_start.h>

/** Management MIC ie */
BWL_PRE_PACKED_STRUCT struct mmic_ie {
	uint8   id;				/* IE ID: DOT11_MNG_MMIE_ID */
	uint8   len;				/* IE length */
	uint16  key_id;				/* key id */
	uint8   ipn[6];				/* ipn */
	uint8   mic[16];			/* mic */
} BWL_POST_PACKED_STRUCT;
typedef struct mmic_ie mmic_ie_t;

#define DOT11_MMIC_IE_HDR_SIZE (OFFSETOF(mmic_ie_t, mic))

/* This marks the end of a packed structure section. */
#include <packed_section_end.h>

#endif	/* _802_11w_h_ */
