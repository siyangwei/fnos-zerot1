#ifndef _LINUX_RFKILL_WLAN_H
#define _LINUX_RFKILL_WLAN_H
/* zt1: fnOS 主线 6.18 没有 rockchip wifi rfkill 驱动（vendor 私有），
 * 这里提供无操作的内联桩，模块电源由 mainline SDIO/regulator 控制。 */
static inline int rockchip_wifi_power(int on) { (void)on; return 0; }
static inline int rockchip_wifi_set_carddetect(int val) { (void)val; return 0; }
static inline int rockchip_wifi_get_oob_irq(void) { return -1; }
static inline int rockchip_wifi_get_oob_irq_flag(void) { return 0; }
static inline int rockchip_wifi_reset(int on) { (void)on; return 0; }
static inline int rockchip_wifi_mac_addr(unsigned char *buf) { (void)buf; return -1; }
static inline void *rockchip_wifi_country_code(char *ccode) { (void)ccode; return 0; }
static inline int rfkill_set_wifi_bt_power(int on) { (void)on; return 0; }
static inline int rfkill_get_wifi_power_state(int *power) { if (power) *power = 1; return 0; }
static inline void *rockchip_mem_prealloc(int section, unsigned long size) { (void)section; (void)size; return 0; }
#endif
